package com.morgado.cpfarmacadastro.caixas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.morgado.cpfarmacadastro.R;

import classes.Dados;
import classes.Tela;

public class NomeActivity extends AppCompatActivity {
    private Button next;
    private EditText inputName;

    private Handler handler = new Handler();
    private Runnable runnableCodigo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nome);
        View decorView = getWindow().getDecorView();

        //esconder navegaçao
        runnableCodigo = new Runnable() {
            @Override
            public void run() {
                Tela.telaCheia(getWindow().getDecorView());
                handler.postDelayed(runnableCodigo, 1000);
            }
        };
        handler.post(runnableCodigo);

        Bundle dados = getIntent().getExtras();
        String codigo = dados.getString("codigo");

        next = findViewById(R.id.btNextNome);
        inputName  = findViewById(R.id.inputName);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(inputName.getText() == null || inputName.getText().toString().isEmpty() || inputName.getText().toString().length() < 9){
                    Toast.makeText(getApplicationContext(), "Digite seu nome completo", Toast.LENGTH_LONG).show();
                }else {
                    Intent intent = new Intent(getApplicationContext(), TelefoneActivity.class);
                    intent.putExtra("codigo", codigo);
                    Dados dados = new Dados();
                    dados.addNome(codigo, inputName.getText().toString() );
                    startActivity(intent);
                }
            }
        });



    }

    @Override
    protected void onStop() {
        super.onStop();
        handler.removeCallbacks(runnableCodigo);
    }
}