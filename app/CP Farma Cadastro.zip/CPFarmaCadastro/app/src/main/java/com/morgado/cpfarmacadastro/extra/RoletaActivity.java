package com.morgado.cpfarmacadastro.extra;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.morgado.cpfarmacadastro.R;

import classes.Dados;
import classes.Tela;

public class RoletaActivity extends AppCompatActivity {

    private Button next;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_roleta);

        Tela.telaCheia(getWindow().getDecorView());

        Bundle dados = getIntent().getExtras();
        String codigo = dados.getString("codigo");

        next = findViewById(R.id.btRoleta);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), CupomActivity.class);
                intent.putExtra("codigo", codigo);
                Dados dados = new Dados();
                dados.addDesconto(codigo, "50");
                startActivity(intent);
            }
        });

    }
}