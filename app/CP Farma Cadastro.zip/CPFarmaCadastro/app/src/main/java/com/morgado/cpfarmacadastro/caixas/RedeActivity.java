package com.morgado.cpfarmacadastro.caixas;
import com.morgado.cpfarmacadastro.R;
import com.morgado.cpfarmacadastro.extra.CupomActivity;
import com.morgado.cpfarmacadastro.extra.GanhouActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import classes.Dados;
import classes.Tela;

public class RedeActivity extends AppCompatActivity {

    private Button next;
    private RadioGroup radios;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rede);

        Tela.telaCheia(getWindow().getDecorView());

        next = findViewById(R.id.btNextRede);
        radios = findViewById(R.id.inputRede);

        Bundle dados = getIntent().getExtras();
        String codigo = dados.getString("codigo");

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Class destino;
                if(radios.getCheckedRadioButtonId() == R.id.radioNao) {
                    destino = GanhouActivity.class;
                }else {
                    destino = QualRedeActivity.class;
                }
                Intent intent = new Intent(getApplicationContext(), destino);
                intent.putExtra("codigo", codigo);
                startActivity(intent);
            }
        });
    }
}