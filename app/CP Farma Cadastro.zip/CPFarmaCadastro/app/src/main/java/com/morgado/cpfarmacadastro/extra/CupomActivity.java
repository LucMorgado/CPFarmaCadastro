package com.morgado.cpfarmacadastro.extra;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.morgado.cpfarmacadastro.R;

import classes.Tela;

public class CupomActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cupom);

        Tela.telaCheia(getWindow().getDecorView());
    }
}