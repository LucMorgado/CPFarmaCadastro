package com.morgado.cpfarmacadastro.caixas;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.morgado.cpfarmacadastro.R;

import classes.Dados;
import classes.MaskEditUtil;
import classes.Tela;

public class TelefoneActivity extends Activity {

    private Button next;
    private EditText inputTelefone;
    private TextView texto;

    private Handler handler = new Handler();
    private Runnable runnableCodigo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_telefone);

        //esconder navegaçao
        runnableCodigo = new Runnable() {
            @Override
            public void run() {
                Tela.telaCheia(getWindow().getDecorView());
                handler.postDelayed(runnableCodigo, 1000);
            }
        };
        handler.post(runnableCodigo);

        inputTelefone = findViewById(R.id.inputTelefone);
        inputTelefone.addTextChangedListener(MaskEditUtil.mask(inputTelefone, MaskEditUtil.FORMAT_FONE));

        Bundle dados = getIntent().getExtras();
        String codigo = dados.getString("codigo");

        next = findViewById(R.id.btNextTelefone);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(inputTelefone.getText().toString().isEmpty() || inputTelefone.getText().toString().length() < 8){
                    Toast.makeText(getApplicationContext(), "Digite seu telefone válido", Toast.LENGTH_LONG).show();
                }else {
                    Intent intent = new Intent(getApplicationContext(), MailActivity.class);
                    intent.putExtra("codigo", codigo);
                    Dados dados = new Dados();
                    dados.addTelefone(codigo, inputTelefone.getText().toString());
                    startActivity(intent);
                }
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        handler.removeCallbacks(runnableCodigo);
    }

}