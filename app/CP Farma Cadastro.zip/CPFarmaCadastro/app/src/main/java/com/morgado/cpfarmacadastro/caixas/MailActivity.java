package com.morgado.cpfarmacadastro.caixas;
import com.morgado.cpfarmacadastro.R;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import classes.Dados;
import classes.Tela;
import classes.ValidaEmail;

public class MailActivity extends AppCompatActivity {

    private Button next;
    private EditText input;

    private Handler handler = new Handler();
    private Runnable runnableCodigo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mail);

        //esconder navegaçao
        runnableCodigo = new Runnable() {
            @Override
            public void run() {
                Tela.telaCheia(getWindow().getDecorView());
                handler.postDelayed(runnableCodigo, 1000);
            }
        };
        handler.post(runnableCodigo);

        next = findViewById(R.id.btNextMail);
        input = findViewById(R.id.inputMail);

        Bundle dados = getIntent().getExtras();
        String codigo = dados.getString("codigo");

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ValidaEmail.isValidEmailAddressRegex(input.getText().toString())) {
                    Intent intent = new Intent(getApplicationContext(), LocalActivity.class);
                    intent.putExtra("codigo", codigo);
                    Dados dados = new Dados();
                    dados.addEmail(codigo, input.getText().toString());
                    startActivity(intent);
                } else
                    Toast.makeText(getApplicationContext(), "Digite um email válido", Toast.LENGTH_LONG).show();
                }
         });
    }
    @Override
    protected void onStop() {
        super.onStop();
        handler.removeCallbacks(runnableCodigo);
    }
}