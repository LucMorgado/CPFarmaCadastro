package com.morgado.cpfarmacadastro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.morgado.cpfarmacadastro.caixas.NomeActivity;

import classes.Dados;
import classes.Tela;

public class MainActivity extends AppCompatActivity {

    private Button btIniciar;
    private String codigo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Tela.telaCheia(getWindow().getDecorView());

        FirebaseDatabase database   = FirebaseDatabase.getInstance();
        DatabaseReference ultimo = database.getReference().child("ultimo");

        ultimo.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                codigo = snapshot.getValue().toString();
                Toast.makeText(getApplicationContext(), codigo, Toast.LENGTH_LONG).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        btIniciar = findViewById(R.id.btIniciar);
        btIniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dados dados = new Dados();
                dados.novo(codigo);
                int novo = Integer.parseInt(codigo) + 1;
                String novoCodigo = novo + "";
                Intent intent = new Intent(getApplicationContext(), NomeActivity.class);
                intent.putExtra("codigo", novoCodigo);
                startActivity(intent);

            }
        });
    }
}