package com.morgado.cpfarmacadastro.extra;
import com.morgado.cpfarmacadastro.R;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import classes.Dados;
import classes.Tela;

public class GanhouActivity extends AppCompatActivity {

    private Button next;
    private TextView finalizar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ganhou);

        Tela.telaCheia(getWindow().getDecorView());

        Bundle dados = getIntent().getExtras();
        String codigo = dados.getString("codigo");

        next = findViewById(R.id.btGanharMais);
        finalizar = findViewById(R.id.btFinalizar);

        finalizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), CupomActivity.class);
                intent.putExtra("codigo", codigo);
                Dados dados = new Dados();
                dados.addDesconto(codigo, "30");
                startActivity(intent);
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), RoletaActivity.class);
                intent.putExtra("codigo", codigo);
                Dados dados = new Dados();
                dados.addDesconto(codigo, "30");
                startActivity(intent);
            }
        });
    }
}